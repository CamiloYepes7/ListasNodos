/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.listan;

import java.util.Scanner;

public class ListaN {

    class Nodo {
        int valor;
        Nodo siguiente;

        public Nodo(int valor) {
            this.valor = valor;
            this.siguiente = null;
        }
    }

    class ListaSimple {
        Nodo cabeza;

        public ListaSimple() {
            cabeza = null;
        }

        public void agregarAlInicio(int nuevoValor) {
            if (!existeElemento(nuevoValor)) {
                Nodo nuevoNodo = new Nodo(nuevoValor);
                nuevoNodo.siguiente = cabeza;
                cabeza = nuevoNodo;
                System.out.println("Elemento agregado al inicio: " + nuevoValor);
            } else {
                System.out.println("No se permite repetir elementos.");
            }
        }

        public void eliminarAlFinal() {
            if (cabeza == null) {
                System.out.println("La lista está vacía, no se puede eliminar ningún elemento.");
                return;
            }

            if (cabeza.siguiente == null) {
                cabeza = null;
            } else {
                Nodo actual = cabeza;
                while (actual.siguiente.siguiente != null) {
                    actual = actual.siguiente;
                }
                actual.siguiente = null;
            }

            System.out.println("Elemento eliminado al final.");
        }

        public boolean existeElemento(int valor) {
            Nodo actual = cabeza;
            while (actual != null) {
                if (actual.valor == valor) {
                    return true;
                }
                actual = actual.siguiente;
            }
            return false;
        }

        public void mostrarLista() {
            if (cabeza == null) {
                System.out.println("La lista está vacía.");
                return;
            }

            Nodo actual = cabeza;
            while (actual != null) {
                System.out.print(actual.valor + " ");
                actual = actual.siguiente;
            }
            System.out.println();
        }

        public int contarElementos() {
            int count = 0;
            Nodo actual = cabeza;
            while (actual != null) {
                count++;
                actual = actual.siguiente;
            }
            return count;
        }
    }

    class ListaCircular {
        Nodo cabeza;

        public ListaCircular() {
            cabeza = null;
        }

        public void agregarAlFinal(int nuevoValor) {
            if (!existeElemento(nuevoValor)) {
                Nodo nuevoNodo = new Nodo(nuevoValor);
                if (cabeza == null) {
                    cabeza = nuevoNodo;
                    nuevoNodo.siguiente = cabeza;
                } else {
                    Nodo actual = cabeza;
                    while (actual.siguiente != cabeza) {
                        actual = actual.siguiente;
                    }
                    actual.siguiente = nuevoNodo;
                    nuevoNodo.siguiente = cabeza;
                }
                System.out.println("Elemento agregado al final: " + nuevoValor);
            } else {
                System.out.println("No se permite repetir elementos.");
            }
        }

        public void eliminarAlInicio() {
            if (cabeza == null) {
                System.out.println("La lista está vacía, no se puede eliminar ningún elemento.");
                return;
            }

            if (cabeza.siguiente == cabeza) {
                cabeza = null;
            } else {
                Nodo actual = cabeza;
                while (actual.siguiente != cabeza) {
                    actual = actual.siguiente;
                }
                actual.siguiente = cabeza.siguiente;
                cabeza = cabeza.siguiente;
            }

            System.out.println("Elemento eliminado al inicio.");
        }

        public boolean existeElemento(int valor) {
            if (cabeza == null) {
                return false;
            }

            Nodo actual = cabeza;
            do {
                if (actual.valor == valor) {
                    return true;
                }
                actual = actual.siguiente;
            } while (actual != cabeza);

            return false;
        }

        public void mostrarLista() {
            if (cabeza == null) {
                System.out.println("La lista circular está vacía.");
                return;
            }

            Nodo actual = cabeza;
            do {
                System.out.print(actual.valor + " ");
                actual = actual.siguiente;
            } while (actual != cabeza);
            System.out.println();
        }

        public int contarElementos() {
            if (cabeza == null) {
                return 0;
            }

            int count = 0;
            Nodo actual = cabeza;
            do {
                count++;
                actual = actual.siguiente;
            } while (actual != cabeza);
            return count;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ListaN listaN = new ListaN();
        ListaN.ListaSimple listaSimple = listaN.new ListaSimple();
        ListaN.ListaCircular listaCircular = listaN.new ListaCircular();

        listaSimple.agregarAlInicio(3);
        listaSimple.agregarAlInicio(7);
        listaSimple.agregarAlInicio(9);
        listaSimple.agregarAlInicio(10);

        listaCircular.agregarAlFinal(3);
        listaCircular.agregarAlFinal(7);
        listaCircular.agregarAlFinal(9);
        listaCircular.agregarAlFinal(10);

        while (true) {
            System.out.println("\nElija una opción:");
            System.out.println("1. Trabajar con Lista Simple");
            System.out.println("2. Trabajar con Lista Circular");
            System.out.println("0. Salir");

            int opcionPrincipal = scanner.nextInt();

            switch (opcionPrincipal) {
                case 1:
                    menuListaSimple(scanner, listaSimple);
                    break;
                case 2:
                    menuListaCircular(scanner, listaCircular);
                    break;
                case 0:
                    System.out.println("¡Hasta luego!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
    }

    private static void menuListaSimple(Scanner scanner, ListaSimple listaSimple) {
        while (true) {
            System.out.println("\nElija una opción para la Lista Simple:");
            System.out.println("1. Agregar nuevo elemento al inicio");
            System.out.println("2. Eliminar último elemento");
            System.out.println("3. Buscar elemento");
            System.out.println("4. Mostrar lista");
            System.out.println("5. Mostrar cantidad de elementos");
            System.out.println("0. Cambiar de lista o salir");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese un nuevo número al inicio:");
                    int nuevoElemento = scanner.nextInt();
                    listaSimple.agregarAlInicio(nuevoElemento);
                    break;
                case 2:
                    listaSimple.eliminarAlFinal();
                    break;
                case 3:
                    System.out.println("Ingrese el elemento a buscar:");
                    int elementoBuscar = scanner.nextInt();
                    if (listaSimple.existeElemento(elementoBuscar)) {
                        System.out.println("El elemento " + elementoBuscar + " está en la Lista Simple.");
                    } else {
                        System.out.println("El elemento " + elementoBuscar + " no está en la Lista Simple.");
                    }
                    break;
                case 4:
                    System.out.println("Lista Simple actual:");
                    listaSimple.mostrarLista();
                    break;
                case 5:
                    System.out.println("Cantidad de elementos en la Lista Simple: " + listaSimple.contarElementos());
                    break;
                case 0:
                    break;
                default:
                      System.out.println("Opción no válida. Intente nuevamente.");
            }

            if (opcion == 0) {
                break; // Salir del bucle interno
            }
        }
    }

    private static void menuListaCircular(Scanner scanner, ListaCircular listaCircular) {
        while (true) {
            System.out.println("\nElija una opción para la Lista Circular:");
            System.out.println("1. Agregar nuevo elemento al final");
            System.out.println("2. Eliminar primer elemento");
            System.out.println("3. Buscar elemento");
            System.out.println("4. Mostrar lista");
            System.out.println("5. Mostrar cantidad de elementos");
            System.out.println("0. Cambiar de lista o salir");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese un nuevo número al final:");
                    int nuevoElemento = scanner.nextInt();
                    listaCircular.agregarAlFinal(nuevoElemento);
                    break;
                case 2:
                    listaCircular.eliminarAlInicio();
                    break;
                case 3:
                    System.out.println("Ingrese el elemento a buscar:");
                    int elementoBuscar = scanner.nextInt();
                    if (listaCircular.existeElemento(elementoBuscar)) {
                        System.out.println("El elemento " + elementoBuscar + " está en la Lista Circular.");
                    } else {
                        System.out.println("El elemento " + elementoBuscar + " no está en la Lista Circular.");
                    }
                    break;
                case 4:
                    System.out.println("Lista Circular actual:");
                    listaCircular.mostrarLista();
                    break;
                case 5:
                    System.out.println("Cantidad de elementos en la Lista Circular: " + listaCircular.contarElementos());
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }

            if (opcion == 0) {
                break; // Salir del bucle interno
            }
        }
    }
}